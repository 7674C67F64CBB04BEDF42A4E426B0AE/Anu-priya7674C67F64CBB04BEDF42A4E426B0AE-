def LinearSearch (ProductList,targetproduct):
  indices=[]
  for index,product in enumerate (ProductList ):
    if Product==targetproduct:
      indices.append(index)
    return indices 
# Example usage:
Product =["shoes","boot","Loafer","shoes ", "sandal","shoes"]
target="shoes"
result=(Product,target)
print(result)

  